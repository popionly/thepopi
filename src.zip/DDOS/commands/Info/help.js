module.exports = {
    name: 'help', 
    category: 'info',
    aliases: ['p'],
    run: (client, message, args) => {
        message.reply("**Layer7**\n`HOAN-V1`\n`HOAN-V2`");
    }
}